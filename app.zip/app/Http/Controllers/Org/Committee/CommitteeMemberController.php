<?php
namespace App\Http\Controllers\Org\Committee;
// use App\Http\Controllers\Controller;
use Illuminate\Routing\Controller;

use App\Models\CommitteeMember;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Log;

class CommitteeMemberController extends Controller
{
    public function __construct()
    {
        $this->middleware('org.permission:committee-member.read')->only(['index', 'show']);
        $this->middleware('org.permission:committee-member.create')->only(['create', 'store']);
        $this->middleware('org.permission:committee-member.update')->only(['edit', 'update']);
        $this->middleware('org.permission:committee-member.delete')->only(['destroy']);
    }
    public function index($id)
    {
        $committeeMember = CommitteeMember::where('committee_id', $id)
            ->leftJoin('users', 'committee_members.user_id', '=', 'users.id')
            ->leftJoin('designations', 'committee_members.designation_id', '=', 'designations.id')
            ->select('committee_members.*', 'users.first_name',  'users.last_name', 'designations.name as designation_name')
            ->get();
        if ($committeeMember->isEmpty()) {
            return response()->json(['status' => false, 'message' => 'No committee members found'], 404);
        }
        return response()->json(['status' => true, 'data' => $committeeMember], 200);
    }
    public function create() {}
    public function store(Request $request)
    {
        // dd($request->all());exit;
        $validator = Validator::make($request->all(), [
            'committee_id' => 'required',
            'user_id' => 'required',
            'designation_id' => 'required',
            'start_date' => 'nullable',
            'end_date' => 'nullable',
            'note' => 'nullable',
            'is_active' => 'nullable',
        ]);
        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'errors' => $validator->errors()
            ], 422);
        }
        try {
            $committeeMember = new CommitteeMember();
            $committeeMember->committee_id = $request->committee_id;
            $committeeMember->user_id = $request->user_id;
            $committeeMember->designation_id = $request->designation_id;
            $committeeMember->start_date = $request->start_date;
            $committeeMember->end_date = $request->end_date;
            $committeeMember->note = $request->note;
            $committeeMember->is_active = $request->is_active;           
            $committeeMember->save();
            return response()->json([
                'status' => true,
                'data' => $committeeMember,
                'message' => 'Meeting Minutes created successfully.'
            ], 201);
        } catch (\Exception $e) {
            Log::error('Error creating Meeting Minutes: ' . $e->getMessage());
            return response()->json([
                'status' => false,
                'message' => 'An error occurred. Please try again.'
            ], 500);
        }
    }
    public function show($id)
    {
        $meetingMinute =  CommitteeMember::select('meeting_minutes.*', 'privacy_setups.id as privacy_id', 'privacy_setups.name as privacy_setup_name')
            ->leftJoin('privacy_setups', 'meeting_minutes.privacy_setup_id', '=', 'privacy_setups.id')
            ->where('meeting_minutes.id', $id)->first();
        if (!$meetingMinute) {
            return response()->json(['status' => false, 'message' => 'Meeting not found'], 404);
        }
        return response()->json(['status' => true, 'data' => $meetingMinute], 200);
    }
    public function edit(CommitteeMember $committeeMember) {}
    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'committee_id' => 'required|integer',
            'user_id' => 'required|integer',
            'designation_id' => 'required|integer',
            'start_date' => 'nullable',
            'end_date' => 'nullable',
            'note' => 'nullable',
            'is_active' => 'required',
        ]);
        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'errors' => $validator->errors()
            ], 422);
        }
        try {
            $committeeMember = CommitteeMember::findOrFail($id);
            $committeeMember->committee_id = $request->committee_id;
            $committeeMember->user_id = $request->user_id;
            $committeeMember->designation_id = $request->designation_id;
            $committeeMember->start_date = $request->start_date;
            $committeeMember->end_date = $request->end_date;
            $committeeMember->note = $request->note;
            $committeeMember->is_active = $request->is_active;
            $committeeMember->save();
            return response()->json([
                'status' => true,
                'data' => $committeeMember,
                'message' => 'Meeting Minutes updated successfully.'
            ], 200);
        } catch (\Exception $e) {
            Log::error('Error updating Meeting Minutes: ' . $e->getMessage());
            return response()->json([
                'status' => false,
                'message' => 'An error occurred. Please try again.'
            ], 500);
        }
    }
    public function destroy($id)
    {
        try {
            $committeeMember = CommitteeMember::findOrFail($id);
            $committeeMember->delete();
            return response()->json([
                'status' => true,
                'message' => 'Meeting Minutes deleted successfully.'
            ], 200);
        } catch (\Exception $e) {
            Log::error('Error deleting Meeting Minutes: ' . $e->getMessage());
            return response()->json([
                'status' => false,
                'message' => 'An error occurred. Please try again.'
            ], 500);
        }
    }
}
