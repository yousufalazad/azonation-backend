<?php

namespace App\Http\Controllers\Common;

use App\Http\Controllers\Controller;

use App\Models\ReferralReward;
use Illuminate\Http\Request;

class ReferralRewardController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(ReferralReward $referralReward)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(ReferralReward $referralReward)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, ReferralReward $referralReward)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(ReferralReward $referralReward)
    {
        //
    }
}
